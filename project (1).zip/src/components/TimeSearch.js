import React from 'react';

export const TimeSearch = ({ searchTerm, onSearchChange, onMonthChange, onYearChange }) => {
  const months = [
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"
  ];
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - 2 + i); // Últimos 2 años, actual y próximos 2

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 flex flex-col sm:flex-row gap-4">
      <input
        type="text"
        placeholder="Buscar por cédula..."
        className="flex-grow px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition duration-200"
        value={searchTerm}
        onChange={(e) => onSearchChange(e.target.value)}
      />
      <select
        className="px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition duration-200"
        onChange={(e) => onMonthChange(e.target.value)}
      >
        <option value="">Buscar por mes...</option>
        {months.map((month, index) => (
          <option key={index} value={month.toLowerCase()}>{month}</option>
        ))}
      </select>
      <select
        className="px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition duration-200"
        onChange={(e) => onYearChange(e.target.value)}
      >
        <option value="">Buscar por año...</option>
        {years.map((year) => (
          <option key={year} value={String(year)}>{year}</option>
        ))}
      </select>
    </div>
  );
};