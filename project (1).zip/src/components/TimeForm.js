import React, { useState } from 'react';

export const TimeForm = ({ onAddRecord, onRecordsAdded }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const lines = input.split('\n').filter(line => line.trim());
    let currentDate = '';
    const newRecords = [];
    
    lines.forEach(line => {
      const parts = line.split(/\s+/);
      
      // Detectar si la línea es una fecha completa (ej. "sábado, 28 de junio de 2025")
      if (parts.length >= 5 && parts.filter(p => p.toLowerCase() === 'de').length >= 2) {
        currentDate = line.trim(); // Captura la línea completa como fecha
      } else {
        let nameParts = [];
        let id = '';
        let entry = '';
        let exit = '';
        let foundId = false;

        for (let i = 0; i < parts.length; i++) {
          if (!foundId && /^\d+$/.test(parts[i])) { 
            id = parts[i];
            foundId = true;
          } else if (foundId && !entry && /^\d{1,2}:\d{2}$/.test(parts[i])) { 
            entry = parts[i];
          } else if (foundId && entry && !exit && /^\d{1,2}:\d{2}$/.test(parts[i])) { 
            exit = parts[i];
          } else if (!foundId) { 
            nameParts.push(parts[i]);
          }
        }
        
        const name = nameParts.join(' ');

        if (name && id && currentDate) {
          newRecords.push({ name, id, date: currentDate, entry: entry || 'N/A', exit: exit || 'N/A' });
        }
      }
    });

    onAddRecord(newRecords);
    onRecordsAdded(newRecords.length); // Notificar cuántos registros se agregaron
    setInput('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
      <div className="space-y-4">
        <div>
          <label htmlFor="records" className="block text-sm font-medium text-gray-700 mb-2">
            Pegar registros (Fecha completa en una línea, luego Nombre Cédula Entrada Salida)
          </label>
          <textarea
            id="records"
            rows="10"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition duration-200 resize-none"
            placeholder={`Ejemplo:\nsábado, 28 de junio de 2025\nCARVAJAL DELGADO BRANDON 1110290035 8:00 17:00\nMEDINA PALACIOS WILSON 94449940 8:00 17:00`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
        <button
          type="submit"
          className="w-full bg-black text-white py-3 px-4 rounded-lg shadow-md hover:bg-gray-800 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black"
        >
          Registrar Horarios
        </button>
      </div>
    </form>
  );
};