import React from 'react';

export const TimeHeader = ({ onClearAllRecords }) => (
  <header className="sticky top-0 z-10 bg-white shadow-sm border-b border-gray-100">
    <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
      <h1 className="text-2xl font-semibold text-gray-900">TimeTrack Pro Limpio</h1>
      <div className="flex space-x-4">
        <button className="px-4 py-2 bg-black text-white rounded-lg shadow-md hover:bg-gray-800 transition-colors duration-200">
          Exportar
        </button>
        <button 
          onClick={onClearAllRecords}
          className="px-4 py-2 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 transition-colors duration-200"
        >
          Limpiar Todo
        </button>
      </div>
    </div>
  </header>
);