import React, { useState } from 'react';

export const TimeTable = ({ records, onEditRecord, onDeleteRecord }) => {
  const [editingId, setEditingId] = useState(null);
  const [currentEdit, setCurrentEdit] = useState({});

  const handleEditClick = (record) => {
    setEditingId(record.id + record.date + record.entry); // Unique ID for editing
    setCurrentEdit({ ...record });
  };

  const handleSaveClick = () => {
    onEditRecord(editingId, currentEdit);
    setEditingId(null);
    setCurrentEdit({});
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentEdit(prev => ({ ...prev, [name]: value }));
  };

  if (records.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No hay registros aún.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto shadow-lg rounded-xl border border-gray-100">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cédula</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entrada</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Salida</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {records.map((record, index) => (
            <tr key={record.id + record.date + record.entry} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              {editingId === (record.id + record.date + record.entry) ? (
                <>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    <input type="text" name="name" value={currentEdit.name} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-2 py-1 focus:ring-black focus:border-black" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <input type="text" name="id" value={currentEdit.id} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-2 py-1 focus:ring-black focus:border-black" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <input type="text" name="date" value={currentEdit.date} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-2 py-1 focus:ring-black focus:border-black" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <input type="text" name="entry" value={currentEdit.entry} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-2 py-1 focus:ring-black focus:border-black" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <input type="text" name="exit" value={currentEdit.exit} onChange={handleChange} className="w-full border border-gray-300 rounded-md px-2 py-1 focus:ring-black focus:border-black" />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onClick={handleSaveClick} className="text-indigo-600 hover:text-indigo-800 mr-3 transition-colors duration-200">Guardar</button>
                    <button onClick={() => setEditingId(null)} className="text-gray-600 hover:text-gray-800 transition-colors duration-200">Cancelar</button>
                  </td>
                </>
              ) : (
                <>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{record.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.entry}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.exit}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onClick={() => handleEditClick(record)} className="text-indigo-600 hover:text-indigo-800 mr-3 transition-colors duration-200">Editar</button>
                    <button onClick={() => onDeleteRecord(record.id + record.date + record.entry)} className="text-red-600 hover:text-red-800 transition-colors duration-200">Eliminar</button>
                  </td>
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};