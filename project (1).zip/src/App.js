import React, { useState, useEffect } from 'react';
import { TimeHeader } from './components/TimeHeader';
import { TimeForm } from './components/TimeForm';
import { TimeSearch } from './components/TimeSearch';
import { TimeTable } from './components/TimeTable';
import { initialRecords } from './mock/records';

export default function App() {
  const [records, setRecords] = useState(() => {
    const savedRecords = localStorage.getItem('timeTrackRecords');
    return savedRecords ? JSON.parse(savedRecords) : initialRecords;
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const [lastAddedCount, setLastAddedCount] = useState(0);

  useEffect(() => {
    localStorage.setItem('timeTrackRecords', JSON.stringify(records));
  }, [records]);

  const handleAddRecord = (newRecords) => {
    setRecords(prev => [...prev, ...newRecords]);
  };

  const handleRecordsAdded = (count) => {
    setLastAddedCount(count);
    setTimeout(() => setLastAddedCount(0), 5000); // El mensaje desaparece después de 5 segundos
  };

  const handleEditRecord = (recordId, updatedRecord) => {
    setRecords(prev => 
      prev.map(record => 
        (record.id + record.date + record.entry) === recordId ? updatedRecord : record
      )
    );
  };

  const handleDeleteRecord = (recordId) => {
    setRecords(prev => prev.filter(record => (record.id + record.date + record.entry) !== recordId));
  };

  const handleClearAllRecords = () => {
    if (window.confirm('¿Estás seguro de que quieres eliminar TODOS los registros? Esta acción no se puede deshacer.')) {
      setRecords([]);
    }
  };

  const filteredRecords = records.filter(record => {
    // Asegurarse de que record.id sea un string antes de usar .includes
    const recordIdString = String(record.id); 
    const matchesSearchTerm = recordIdString.includes(searchTerm);
    
    // Extraer el nombre del mes y el año de la fecha completa
    let recordMonth = '';
    let recordYear = '';
    if (record.date) { 
      const dateParts = record.date.split(' ');
      // Asumiendo formato "día_semana, día de mes de año"
      // Ejemplo: "sábado, 28 de junio de 2025"
      // parts[0] = "sábado,"
      // parts[1] = "28"
      // parts[2] = "de"
      // parts[3] = "junio"
      // parts[4] = "de"
      // parts[5] = "2025"
      if (dateParts.length >= 6) { 
        recordMonth = dateParts[3]?.toLowerCase(); 
        recordYear = dateParts[5]; 
      }
    }
    
    const matchesMonth = selectedMonth ? recordMonth === selectedMonth : true;
    const matchesYear = selectedYear ? recordYear === selectedYear : true;
    
    return matchesSearchTerm && matchesMonth && matchesYear;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <TimeHeader onClearAllRecords={handleClearAllRecords} />
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 space-y-8">
        <TimeForm onAddRecord={handleAddRecord} onRecordsAdded={handleRecordsAdded} />
        {lastAddedCount > 0 && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative" role="alert">
            <span className="block sm:inline">¡Se registraron {lastAddedCount} empleados!</span>
          </div>
        )}
        <TimeSearch 
          searchTerm={searchTerm} 
          onSearchChange={setSearchTerm} 
          onMonthChange={setSelectedMonth} 
          onYearChange={setSelectedYear}
        />
        <TimeTable 
          records={filteredRecords} 
          onEditRecord={handleEditRecord} 
          onDeleteRecord={handleDeleteRecord} 
        />
      </main>
    </div>
  );
}

// DONE