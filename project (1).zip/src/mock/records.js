export const initialRecords = [
  {
    name: "Ejemplo Empleado",
    id: "123456789",
    date: "sábado, 28 de junio de 2025",
    entry: "09:00",
    exit: "18:00"
  },
  {
    name: "Otro Empleado",
    id: "987654321",
    date: "viernes, 27 de mayo de 2024",
    entry: "08:30",
    exit: "17:30"
  },
  {
    name: "Juan Pérez",
    id: "1110290035",
    date: "sábado, 28 de junio de 2025",
    entry: "08:00",
    exit: "17:00"
  },
  {
    name: "María García",
    id: "1110290035",
    date: "lunes, 30 de junio de 2024",
    entry: "09:00",
    exit: "18:00"
  },
  {
    name: "Carlos Ruiz",
    id: "94449940",
    date: "sábado, 28 de junio de 2025",
    entry: "08:00",
    exit: "17:00"
  },
  {
    name: "Ana López",
    id: "94449940",
    date: "martes, 1 de julio de 2024",
    entry: "08:30",
    exit: "17:30"
  }
];